		<div id="header" style="text-align:center">
			<p>ERROR</p>
		</div>
		<div id="content">
				<div class="form-container">			
					<form action="" method="post">		
					<fieldset>
						<div style="color: #FF0000;"><b>SE HA PRODUCIDO UN ERROR, POR FAVOR AVISE A SU ADMINISTRADOR.</b></div>
						<br></br>
						<div style="color: #FF0000;"><b>MUCHAS GRACIAS</b></div>						
					</fieldset>
					</form>
				</div>
		</div>
</body>
</html>