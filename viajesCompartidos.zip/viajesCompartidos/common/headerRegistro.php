<?php
ob_start();

echo "<div id=\"header\">";
?>
<body>
	<p id="alignleft"><?php print(VIEW_PAGE_TITLE.' - '.VIEW_EMPRESA); ?></p>
	</p>
	</div>
	<div><p></div>