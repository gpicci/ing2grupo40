<?php
class FiltroDB
{
    // Declaraci�n de la propiedad
    public $campo = "";
    public $valor = "%";
    public $tipoDato = "S"; //S: string ; N: number
}
?>